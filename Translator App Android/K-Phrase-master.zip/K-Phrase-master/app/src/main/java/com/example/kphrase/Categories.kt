package com.example.kphrase

import java.io.Serializable

class Categories(
    var Id: String,
    var ENG_NAME: String,
    var ENG_KOR_NAME: String,
    var KOREAN: String,
    var AUDIO_FILE_NAME: String): Serializable {

}