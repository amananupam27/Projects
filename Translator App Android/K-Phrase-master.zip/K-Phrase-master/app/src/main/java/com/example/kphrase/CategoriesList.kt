package com.example.kphrase

import java.io.Serializable

class CategoriesList (var categorie: ArrayList<Categories>?): Serializable {

}