package com.example.kphrase

object Favorites {
    var fav = ArrayList<Categories>()
}