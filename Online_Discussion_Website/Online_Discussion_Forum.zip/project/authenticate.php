<?php

include_once('conn.php');
$id=$_POST['email'];
$pwd=$_POST['pwd'];

$result=mysqli_query($conn, 'select * from login_info where email="'.$id.'" AND pwd="'.$pwd.'" ');

$data=mysqli_fetch_assoc($result);
$cnt=mysqli_num_rows($result);

$sr=$data['sr'];
if($cnt==1)
{
	$result=mysqli_query($conn, 'select * from login_info where email="'.$id.'" AND pwd="'.$pwd.'" AND status="1" ');
	$data=mysqli_fetch_assoc($result);
	$cnt=mysqli_num_rows($result);
	if($cnt==1)
	{
		$sr=$data['sr'];
		session_start();
		$_SESSION["sr"] = $sr;
		header("location:dashboard.php");
	}
	else
	{
		header("location:login.php?a=User Blocked");
	}
}
else
{
	header("location:login.php?a=Login Error");
}

?>