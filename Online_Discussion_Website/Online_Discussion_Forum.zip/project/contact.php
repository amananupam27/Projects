
<html>
<head>
<title>Contact Us</title>
<style>
.footer {
   
   left: 0;
   bottom: 0;
   width: 100%;
   background-color: black;
   color: white;
   text-align: center;
}
</style>

<style>
.row{
	
	
  content: "";
  display: table;
  clear: both;
  border: 1px solid black ;
  padding: 10px;
  margin-left: 5%;
  margin-right: 5%;
  width: 90%;
  background-color: #d3d3d3;
}

body{
	
	background-image: url("images/background.jpg");
	 

	background-repeat:repeat;
}

</style>
<style>
.button {
  background-color: #000099;
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}
</style>
</head>
<body>
<?php
include_once('header.php');
include_once('conn.php');
?>

<h3><center>Drop us a message<br>
<?php echo @$_GET['a'];?>
</center></h3><hr>

<div class="row"  > 

<h3>Comments/Suggestions/Ask your queries here:</h3>
<form action="contact_send.php" method="POST">


Enter your email:<br>
<input type="email" name="email" required="required">
<br><br>

Enter title:<br>
<input type="text" name="title" required="required">
<br><br>
Description:<br>
<textarea rows="10" cols="100" name="content" required="required"></textarea>
<br><br>

<br>
<br>
<button type="submit" class="button">Submit</button>

</form>


</div>
<br>

<div class="footer">
  <p>DiscussAnythingHere</p>
  All Rights Reserved 2019
</div>
</body>
</html>
