<?php
$id=$_POST['userid'];
$pwd=$_POST['pwd'];
include_once('conn.php');

$sql=mysqli_query($conn,'select * from admin_login where username="'.$id.'" AND pwd="'.$pwd.'"');
$data=mysqli_fetch_assoc($sql);

if($data[username]=='aman')
{
	header('location:admin_dashboard.php?id='.$id.'');
	
}
else
{
	header('location:admin.php');
	
	
}
?>