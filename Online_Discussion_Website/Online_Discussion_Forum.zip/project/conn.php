<?php
$conn=mysqli_connect('localhost','root','','basedata');

if(!$conn)
{
echo 'error';
}
?>