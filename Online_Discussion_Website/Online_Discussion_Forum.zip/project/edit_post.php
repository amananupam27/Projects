<html>
<head>
<style>
.footer {
   
   left: 0;
   bottom: 0;
   width: 100%;
   background-color: black;
   color: white;
   text-align: center;
}
</style>
<style>
.button {
  background-color: #000099;
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}
</style>
<style>
.row{
	
	
  content: "";
  display: table;
  clear: both;
  border: 1px solid black ;
  padding: 10px;
  margin-left: 5%;
  margin-right: 5%;
  width: 90%;
}

body{
	
	background-image: url("images/background.jpg");
	 

	background-repeat:repeat;
}
.column2
{
	
	float: left;
  width: 90%;
  padding: 10px;
  
	
	
}

</style>
</head>
<body>
<?php
include_once('header.php');
include_once('conn.php');

$p_id=$_GET['p_id'];

$sql=mysqli_query($conn, 'select * from all_posts where post_id="'.$p_id.'"');
$data=mysqli_fetch_assoc($sql);


?>






<div class="row" style="background-color:#FFFFFF;" >
 
 
			<div class="column2">
			<h3>Update Post</h3>
			<form action="update_post.php" method="POST">
			<input type="hidden" value="<?php echo $p_id; ?>" name="p_id">
			Title:<br><input type="text" value="<?php echo $data['title']; ?>" name="title"><br>
			<br>
			Content:<br><textarea rows="15" cols="100" name="content"><?php echo $data['content']; ?></textarea>
			<br><br>
			<button type="submit" class="button">Submit</button>
			</form>
			 
			
			 </div><br>

			 
			 
			 </div><br>
					

<div class="footer">
  <p>DiscussAnythingHere</p>
  All Rights Reserved 2019
</div>
</body>
</html>