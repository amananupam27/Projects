<?php
$id=$_GET['id'];
include_once('conn.php');
?>

<html>
<head>
<style>

body{
	
	background-image: url("images/background.jpg");
	 

	background-repeat:repeat;
}
.column {
  float: left;
  width: 70%;
  padding: 5px;
  
}
.row{
	
	
  content: "";
  display: table;
  clear: both;
  border: 1px solid green ;
  padding: 10px;
  margin-left: 5%;
  margin-right: 5%;
  width: 90%;
}
.button {
  background-color: #000099;
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}

.footer {
  
   left: 0;
   bottom: 0;
   width: 100%;
   background-color: black;
   color: white;
   text-align: center;
}
</style>
</head>
<body>
<?php


$id=$_GET['id'];
include_once('header.php');
?>

<?php

if($id=='aman')
{
$sql=mysqli_query($conn, 'select * from login_info;');
$count=0;

while($data=mysqli_fetch_assoc($sql))
{
	$count++;
	
	if($data['status']=="1")
		$st="Active";
	else
		$st="Blocked";
	
echo '<div class="row" style="background-color:#bbb;" >  
 <div class="column">
 Email: '.$data['email'].' 
 </div>
 <div class="column">
 Name: '.$data['name'].' 
 </div>
 
 <div class="column">
 Contact: '.$data['phone'].' 
 </div>
 
 <div class="column">
 Status: '.$st.' 
 </div>
 
<div class="column">
<a href="user_block.php?id='.$id.' && userid='.$data['sr'].'"><button type="submit" class="button">Block User</button></a>
 
<a href="user_unblock.php?id='.$id.' && userid='.$data['sr'].'"><button type="submit" class="button">Unblock User</button></a>
 
<a href="user_delete.php?id='.$id.' && userid='.$data['sr'].'"><button type="submit" class="button">Delete User</button></a>

<a href="user_delete_posts.php?id='.$id.' && userid='.$data['sr'].'"><button type="submit" class="button">Delete User Posts</button></a>
 </div>
 
 
 </div><br>';
}
}
?>
<div class="footer">
  <p>DiscussAnythingHere</p>
  All Rights Reserved 2019
</div>
</body>
</html>