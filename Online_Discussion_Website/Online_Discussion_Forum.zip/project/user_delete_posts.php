<?php
$userid=$_GET['userid'];
$id=$_GET['id'];

include_once('conn.php');

mysqli_query($conn, 'delete from all_posts where sr="'.$userid.'";');

mysqli_query($conn, 'delete from post_reply where sr="'.$userid.'";');

header('location:admin_dashboard.php?id='.$id.'');
?>


