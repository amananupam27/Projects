<?php
include_once('conn.php');

$c_id=$_POST['c_id'];
$p_id=$_POST['p_id'];
$comment=$_POST['content'];

mysqli_query($conn,'update post_reply set comment="'.$comment.'" where c_id="'.$c_id.'"');

header('location:view_detail.php?id='.$p_id.'');

?>

