<?php
$email=$_POST['email'];
$title=$_POST['title'];
$content=$_POST['content'];

include_once('conn.php');
mysqli_query($conn,'insert into contacts (email, title, description)  values ("'.$email.'","'.$title.'","'.$content.'")');

header('location:contact.php?a=Thank You. We will respond soon');
?>