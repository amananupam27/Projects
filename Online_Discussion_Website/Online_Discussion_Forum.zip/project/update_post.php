<?php

include_once('conn.php');
$p_id=$_POST['p_id'];
$title=$_POST['title'];
$content=$_POST['content'];

mysqli_query($conn, 'update all_posts set title="'.$title.'", content="'.$content.'" where post_id="'.$p_id.'";');
header('location:dashboard.php?c=Post Updated');
?>