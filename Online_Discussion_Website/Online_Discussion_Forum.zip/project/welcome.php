<?php

include_once('conn.php');
include_once('header.php');
$name=$_POST['name'];
$phone=$_POST['phone'];
$email=$_POST['email'];
$pwd=$_POST['pwd'];
$pwd2=$_POST['pwd2'];
$d="Passwords don't match";
if($pwd!=$pwd2)
{
    header("location:register.php?a=$name && b=$phone&&c=$email&& d=$d");
}



$result = mysqli_query($conn,'select * from login_info where email="'.$email.'";');

$row_cnt = mysqli_num_rows($result);
if ($row_cnt==0) {

mysqli_query($conn,'insert into login_info(email,pwd,name,phone,status) values ("'.$email.'","'.$pwd.'","'.$name.'","'.$phone.'","1");');   
echo '<h2><center>ACCOUNT CREATED SUCCESSFULLY</center></h2>';
echo'<br><br><center> <a href="login.php">Click here to login</a></center>';
 
}
else
{
	header("location:register.php?a=$name && b=$phone&&c=$email&& d=Email already exists");
			
	
}


?>