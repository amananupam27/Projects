<?php
session_start();
$id=$_SESSION['sr'];
$email=$_POST['email'];
$pwd=$_POST['pwd'];
$name=$_POST['name'];
$phone=$_POST['phone'];


include_once('conn.php');

mysqli_query($conn, 'update login_info set email="'.$email.'", pwd="'.$pwd.'", name="'.$name.'", phone="'.$phone.'" where sr="'.$id.'"');

header('location:dashboard.php?info=Profile Updated');
?>