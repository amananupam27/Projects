<?php

include_once('conn.php');
session_start();

$sr=$_SESSION['sr'];
$title=$_POST['title'];
$content=$_POST['content'];
$currentDateTime = date('Y-m-d H:i:s');

$img_name=$_FILES['image']['name'];
$img_tmp=$_FILES['image']['tmp_name'];

$temp = explode(".", $img_name);
$newfilename = round(microtime(true)) . '.' . end($temp);

$post_id=round(microtime(true));

move_uploaded_file($_FILES["image"]["tmp_name"], "images/" . $newfilename);

$success=mysqli_query($conn, 'insert into all_posts (sr, title, content, image_path, date, post_id) values  ("'.$sr.'","'.$title.'","'.$content.'","'.$newfilename.'","'.$currentDateTime.'","'.$post_id.'"); ');

if($success!=NULL)
{
$mess="Post Created Successfully";
header("location:dashboard.php?a=$mess");
}
?>