<?php

include('header.php');

session_destroy();

echo '<center><h2><b>Logout Successfull</b></h2>
<br>
<a href="index.php">Go To Homepage</a>

</center>';


?>