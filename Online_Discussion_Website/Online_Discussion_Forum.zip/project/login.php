<html>
<head><title>Login</title>
<style>
.footer {
   position: absolute;
   left: 0;
   bottom: 0;
   width: 100%;
   background-color: black;
   color: white;
   text-align: center;
}
</style>
<style>
.button {
  background-color: #000099;
  border: none;
  color: white;
  padding: 12px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}
</style>
<style>

body{
	
	background-image: url("images/background.jpg");
	 

	background-repeat:repeat;
}

.rectangle {
  height: 320px;
  width: 500px;
  background-color: #FFFFFF;
  
 
  position: absolute;
  left: 50%;
  top: 50%;
  transform: translate(-50%, -50%);
  
}
</style>
<style> 
input[type=value] {
  width: 60%;
  padding: 6px ;

  box-sizing: border-box;
  
}
</style>
</head>

<body bgcolor="gray">
<?php
include('header.php');
?>

<div class="rectangle">
<h3><center>Sign In</center></h3>
<br>

<form action="authenticate.php" method="post">
<center>Email</center><br>
<center><input type="email" name="email"></center><br>

<center>Password</center><br>
<center><input type="password" name="pwd"></center><br>

<center><button type="submit" class="button">Submit</button></center>
<center><a href="register.php">Create a new account</a></center>
<?php 
echo '<center>'.@$_GET['a'].'</center>';
?>
</form>
    
    
</div>
<div class="footer">
  <p>DiscussAnythingHere</p>
  All Rights Reserved 2019
</div>

</body>
</html>