<html>
<head>
<style>
.footer {
   position: absolute;
   left: 0;
   bottom: 0;
   width: 100%;
   background-color: black;
   color: white;
   text-align: center;
}
</style>
<style>
.button {
  background-color: #000099;
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}
</style>
<style>
.row{
	
	
  content: "";
  display: table;
  clear: both;
  border: 1px solid black ;
  padding: 10px;
  margin-left: 5%;
  margin-right: 5%;
  width: 90%;
}

body{
	
	background-image: url("images/background.jpg");
	 

	background-repeat:repeat;
}
.column2
{
	
	float: left;
  width: 90%;
  padding: 10px;
  
	
	
}

</style>
</head>
<body>
<?php
include_once('header.php');
include_once('conn.php');

$sr=$_SESSION['sr'];
$result=mysqli_query($conn, 'select * from login_info where sr="'.$sr.'"');

$data=mysqli_fetch_assoc($result);
?>







<div class="row" style="background-color:#FFFFFF;" >
 
 
			<div class="column2">
			<h3>Update Post</h3>
			<form action="update_profile.php" method="POST">
			
			<table border="0">
			<tr>
			<td>Name:</td><td><input type="text" value="<?php echo $data['name']; ?>" name="name"></td>
			</tr>
			<tr>
			<td>Email:</td><td><input type="text" value="<?php echo $data['email']; ?>" name="email"></td>
			</tr>
			<tr>
			<td>Password:</td><td><input type="password" value="<?php echo $data['pwd']; ?>" name="pwd"></td>
			</tr>
			<tr>
			<td>Phone Number:</td><td><input type="text" value="<?php echo $data['phone']; ?>" name="phone"><br></td>
			</tr>
			<tr >
			<td colspan="2"><button type="submit"  class="button">Update</button></td>
			</tr>
			</table>
			</form>
			 
			
			 </div><br>

			 
			 
			 </div><br>
					
<div class="footer">
  <p>DiscussAnythingHere</p>
  All Rights Reserved 2019
</div>

</body>
</html>