<html>
<head>
<style>
.footer {
   position: absolute;
   left: 0;
   bottom: 0;
   width: 100%;
   background-color: black;
   color: white;
   text-align: center;
}
</style>


<style>

body{
	
	background-image: url("images/background.jpg");
	 

	background-repeat:repeat;
}
</style>
</head>
<body>
<?php
include_once('header.php');
?>

<h3><center>About Us</center></h3>
<hr>
<center>
This project has been developed by the combined efforts and teamwork of-
<br><br>
Aman Malhotra: 17BCA1036
<br>
Aman Saxena: 17BCA1283
<br><br>
Email1: malhotraaman76@gmail.com
<br>
Email2: amananupam27@gmail.com

</center>
<div class="footer">
  <p>DiscussAnythingHere</p>
  All Rights Reserved 2019
</div>
</body>
</html>