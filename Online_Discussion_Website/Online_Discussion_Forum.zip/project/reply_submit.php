<?php
include_once('conn.php');
session_start();
$sr=$_SESSION['sr'];
$content=$_POST['reply'];
$p_id=$_POST['p_id'];

$c_id= round(microtime(true));
$currentDateTime = date('Y-m-d H:i:s');
mysqli_query($conn, 'insert into post_reply (sr,p_id,c_id,comment, date) values("'.$sr.'","'.$p_id.'","'.$c_id.'","'.$content.'","'.$currentDateTime.'");');

header("location:view_detail.php?id=$p_id");
?>