<html>
<head>
<title>Welcome to DiscussAnythingHere</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
.footer {
   
   left: 0;
   bottom: 0;
   width: 100%;
   background-color: black;
   color: white;
   text-align: center;
}
</style>
<style>
.button {
  background-color: #000099;
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}
</style>
<style>

.column {
  float: left;
  width: 100%;
  padding: 10px;
  
}

.column2
{
	
	float: left;
  width: 10%;
  padding: 10px;
  
	
	
}



.row{
	
	
  content: "";
  display: table;
  clear: both;
  border: 1px solid black ;
  padding: 10px;
  margin-left: 5%;
  margin-right: 5%;
  width: 90%;
}


</style>

<style>
body{
	
	background-image: url("images/background.jpg");
	
	
	background-repeat:repeat;
}

body, html {
  height: 100%;
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
	 


}

.hero-image {
  background-image: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url("images/hero.jpg");
  height: 50%;
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
  position: relative;
}

.hero-text {
  text-align: center;
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  color: white;
}

.hero-text button {
  border: none;
  outline: 0;
  display: inline-block;
  padding: 10px 25px;
  color: black;
  background-color: #ddd;
  text-align: center;
  cursor: pointer;
}

.hero-text button:hover {
  background-color: #555;
  color: white;
}
</style>
</head>
<body>
<?php
include('header.php');
?>

<div class="hero-image">
  <div class="hero-text">
    <h1 style="font-size:50px">Discuss Anything Here</h1>
    <p>Great discussions live here.</p>
    
  </div>
</div>


<?php
include_once('conn.php');
$query=mysqli_query($conn, 'select * from all_posts order by date desc');

echo '<br>';

while($data=mysqli_fetch_assoc($query))
{

$query2=mysqli_query($conn,'select * from login_info where sr="'.$data['sr'].'"');
$data2=mysqli_fetch_assoc($query2);
echo '<div class="row" style="background-color:#bbb;" >
 
 
 <div class="column">
 <b>'.$data['title'].'</b>
 <br>
 <hr>
 <i>Asked By: '.$data2['name'].'</i><br>
 <i>Uploaded on: '.$data['date'].'</i>
 </div>

 <div class="column">
 '.nl2br($data['content']).'
 </div>
  
 <div class="column">
 <a href="view_detail.php?id='.$data['post_id'].'"><button class="button">View or Discuss</button></a>
 </div>
 </div><br>';
	

}


?>

<div class="footer">
  <p>DiscussAnythingHere</p>
  All Rights Reserved 2019
</div>

</body>

</html>