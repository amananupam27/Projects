<script>
function showDiv() {
   document.getElementById('welcomeDiv').style.display = "block";
}


</script>
<style>
.footer {
   
   left: 0;
   bottom: 0;
   width: 100%;
   background-color: black;
   color: white;
   text-align: center;
}
</style>
<style>
.button {
  background-color: #000099;
  border: none;
  color: white;
  padding: 12px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}
</style>
<style>

.column {
  float: left;
  width: 100%;
  padding: 10px;
  
}

.column2
{
	
	float: left;
  width: 10%;
  padding: 10px;
  
	
	
}

.column3
{
	
	float: left;
  width: 100%;
  padding: 10px;
  
	
	
}



.row{
	
	
  content: "";
  display: table;
  clear: both;
  border: 1px solid black ;
  padding: 10px;
  margin-left: 5%;
  margin-right: 5%;
  width: 90%;
}
.row2{
	
	
  content: "";
  display: table;
  clear: both;
  border: 1px solid black ;
  padding: 10px;
  margin-left: 5%;
  margin-right: 5%;
  width: 90%;
}

body{
	
	background-image: url("images/background.jpg");
	 

	background-repeat:repeat;
}
</style>



<?php
include_once('conn.php');
include_once('header.php');
$p_id=$_GET['id'];

$query=mysqli_query($conn, 'select * from all_posts where post_id="'.$p_id.'"');

$data=mysqli_fetch_assoc($query);

$query2=mysqli_query($conn, 'select * from login_info where sr="'.$data['sr'].'"');
$data2=mysqli_fetch_assoc($query2);


echo '<div class="row" style="background-color:#D0D0D0;" >
 
 
 <div class="column">
 <b>'.$data['title'].'</b>
 <br>
 <hr>
 <i>Asked By: '.$data2['name'].'</i><br>
 <i>Uploaded on: '.$data['date'].'</i>
 </div>

 <div class="column">
 ';
 
 $img='images/'.@$data['image_path'];
 if (file_exists($img)) {
    echo '<img src="'.$img.'" height="300px" width="300px">';
   
}


 
 echo '</div>
 
 
 <div class="column">
 '.nl2br($data['content']).'
 </div>
  
 <div class="column">
';


$que=mysqli_query($conn, 'select * from post_reply where p_id="'.$p_id.'"');


if($que!=NULL)
{
	while($datac=mysqli_fetch_assoc($que))
	{
		
		
		$que2=mysqli_query($conn, 'select * from login_info where sr="'.$datac['sr'].'"');
		$datac2=mysqli_fetch_assoc($que2);
		
		echo '<div class="row2" style="background-color:#FFFFFF;" >
 
 
				<div class="column3">
			
			 
			
			 <b><i>By: '.$datac2['name'].'</i></b><br>
			 <hr>
			 <i>Uploaded on: '.$datac['date'].'</i>
			 </div><br>

			 <div class="column3">
			 '.nl2br($datac['comment']).'
			 </div>
			 
			 
			 <div class="column3">';
			 
			if(@$_SESSION['sr']==@$datac['sr'])
			{
				echo '
				<button onclick="showDiv()" class="button">Edit</button>
				<a href="delete_comment.php?c_id='.@$datac['c_id'].' && p_id='.$p_id.' "><button class="button">Delete</button></a>
				<div id="welcomeDiv"  style="display:none;" class="answer_list" >
				
				<br>
				<form action="edit_comment.php" method="POST">
				<input type="hidden"  value="'.@$p_id.'" name="p_id">
				<input type="hidden"  value="'.@$datac['c_id'].'" name="c_id">
				Text:<br>
				<textarea rows="15" cols="80"  name="content">
				'.@$datac['comment'].'
				</textarea><br>
				<button type="submit" class="button">Update</button>
				
				</form>
		
				</div>
				';
				
			}
			 
			 echo '</div>
			 
			 </div><br>';
					
		
		
		
	}

	
} 
 if(@$_SESSION['sr']==0)
 {
	 echo '
	  <h3>Answer this Question?</h3>
	 <br><a href="login.php"><button class="button">Login/SignUp to Answer</button></a>';
	 
 }
 else
 {
	 echo '<H3>Answer this question: </H3><br>';
	 
	 
	 
	 echo '
	 <form method="POST" action="reply_submit.php">
	 <input type="hidden"  name="p_id" value="'.$data['post_id'].'">
	 <textarea rows="15" cols="100" name="reply"></textarea>
	 <br><br>
	 <button type="submit" class="button">Submit</button>
	 </form>
	 
	 ';
	 
 }
 
 
 
 echo  '</div>
 </div><br>';


echo '
<div class="footer">
  <p>DiscussAnythingHere</p>
  All Rights Reserved 2019
</div>';

?>