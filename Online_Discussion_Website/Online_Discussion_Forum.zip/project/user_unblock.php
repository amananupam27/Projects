<?php
$userid=$_GET['userid'];
$id=$_GET['id'];

include_once('conn.php');

mysqli_query($conn, 'update login_info set status = "1" where sr="'.$userid.'"; ');

header('location:admin_dashboard.php?id='.$id.'');
?>

