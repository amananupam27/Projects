<?php
$img=$_GET['a'];

include_once('conn.php');
mysqli_query($conn, 'delete from all_posts where post_id="'.$img.'"');
header("location:dashboard.php");
?>