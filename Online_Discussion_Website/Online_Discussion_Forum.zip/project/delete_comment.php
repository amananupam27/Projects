<?php
include_once('conn.php');

$c_id=$_GET['c_id'];
$p_id=$_GET['p_id'];
mysqli_query($conn, 'delete from post_reply where c_id="'.$c_id.'"');
header('location:view_detail.php?id='.$p_id.'');
?>