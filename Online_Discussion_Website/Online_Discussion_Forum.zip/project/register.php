<html>
<head><title>Register</title>

<style>
/* The message box is shown when the user clicks on the password field */
#message {
  display:none;
  background: #f1f1f1;
  color: #000;
  position: relative;
  padding: 20px;
  margin-top: 10px;
}

#message p {
  padding: 10px 35px;
  font-size: 18px;
}

/* Add a green text color and a checkmark when the requirements are right */
.valid {
  color: green;
}

.valid:before {
  position: relative;
  left: -35px;
  content: "✔";
}

/* Add a red text color and an "x" when the requirements are wrong */
.invalid {
  color: red;
}

.invalid:before {
  position: relative;
  left: -35px;
  content: "✖";
}
</style>

<style>
.footer {
   position: fixed;
   left: 0;
   bottom: 0;	
   width: 100%;
   background-color: black;
   color: white;
   text-align: center;
}
</style>
<style>
.button {
  background-color: #000099;
  border: none;
  color: white;
  padding: 12px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}
</style>
<style>
body{
	
	background-image: url("images/background.jpg");
	 

	background-repeat:repeat;
}

.rectangle {
  height: 600px;
  width: 500px;
  background-color: #FFFFFF;
  
 
  position: absolute;
  left: 50%;
  top: 50%;
  transform: translate(-50%, -30%);
  
}
</style>
<style> 
input[type=value],input[type=password],input[type=email] {
  width: 60%;
  padding: 6px ;

  box-sizing: border-box;
  
}


</style>



</head>

<body bgcolor="gray">
<?php
include('header.php');
?>

<div class="rectangle">
<h3><center>Create a new account</center></h3>
<br>

<form action="welcome.php" method="post">
<center>Name</center><br>
<center><input type="value" name="name"></center><br>

<center>Email</center><br>
<center><input type="email" name="email"></center><br>


<center>Password</center><br>
<center><input type="password" name="pwd" id="pwd" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" required></center><br>

<div id="message">
  <h3>Password must contain the following:</h3>
  <p id="letter" class="invalid">A <b>lowercase</b> letter</p>
  <p id="capital" class="invalid">A <b>capital (uppercase)</b> letter</p>
  <p id="number" class="invalid">A <b>number</b></p>
  <p id="length" class="invalid">Minimum <b>8 characters</b></p>
</div>

<center>Re-enter Password</center><br>
<center><input type="password" name="pwd2"></center><br>


<center>Phone</center><br>
<center><input type="value" name="phone"></center><br>

<center><button type="submit" class="button">Submit</button></center><br><br><br><br><br>
<center><?php
echo @$_GET['d'];
?>
</center>
</form>
   <br>
   <br> 
</div><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<div class="footer">
  <p>DiscussAnythingHere</p>
  All Rights Reserved 2019
</div>

<script>
var myInput = document.getElementById("pwd");
var letter = document.getElementById("letter");
var capital = document.getElementById("capital");
var number = document.getElementById("number");
var length = document.getElementById("length");

// When the user clicks on the password field, show the message box
myInput.onfocus = function() {
  document.getElementById("message").style.display = "block";
}

// When the user clicks outside of the password field, hide the message box
myInput.onblur = function() {
  document.getElementById("message").style.display = "none";
}

// When the user starts to type something inside the password field
myInput.onkeyup = function() {
  // Validate lowercase letters
  var lowerCaseLetters = /[a-z]/g;
  if(myInput.value.match(lowerCaseLetters)) {  
    letter.classList.remove("invalid");
    letter.classList.add("valid");
  } else {
    letter.classList.remove("valid");
    letter.classList.add("invalid");
  }
  
  // Validate capital letters
  var upperCaseLetters = /[A-Z]/g;
  if(myInput.value.match(upperCaseLetters)) {  
    capital.classList.remove("invalid");
    capital.classList.add("valid");
  } else {
    capital.classList.remove("valid");
    capital.classList.add("invalid");
  }

  // Validate numbers
  var numbers = /[0-9]/g;
  if(myInput.value.match(numbers)) {  
    number.classList.remove("invalid");
    number.classList.add("valid");
  } else {
    number.classList.remove("valid");
    number.classList.add("invalid");
  }
  
  // Validate length
  if(myInput.value.length >= 8) {
    length.classList.remove("invalid");
    length.classList.add("valid");
  } else {
    length.classList.remove("valid");
    length.classList.add("invalid");
  }
}
</script>

</body>
</html>