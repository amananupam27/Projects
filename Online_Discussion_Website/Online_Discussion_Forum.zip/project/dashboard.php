


<html>
<head>
<title> Welcome To Dashboard </title>
<style>
.footer {
   
   left: 0;
   bottom: 0;
   width: 100%;
   background-color: black;
   color: white;
   text-align: center;
}
</style>
<style>
.button {
  background-color: #000099;
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}
</style>
<style>

body{
	
	background-image: url("images/background.jpg");
	 

	background-repeat:repeat;
}


.column {
  float: left;
  width: 70%;
  padding: 10px;
  
}

.column2
{
	
	float: left;
  width: 10%;
  padding: 10px;
  
	
	
}



.row{
	
	
  content: "";
  display: table;
  clear: both;
  border: 1px solid green ;
  padding: 10px;
  margin-left: 5%;
  margin-right: 5%;
  width: 90%;
}

.answer_list
{
	content: "";
  display: table;
  clear: both;
  border: 1px solid green ;
  padding: 10px;
  margin-left: 5%;
  margin-right: 5%;
  width: 90%;
	
}
</style>

<script>
function showDiv() {
   document.getElementById('welcomeDiv').style.display = "block";
}


</script>




</head>
<body>
<?php
include_once('header.php');
include_once('conn.php');

$sr=$_SESSION['sr'];
$result=mysqli_query($conn, 'select * from login_info where sr="'.$sr.'"');

$data=mysqli_fetch_assoc($result);
?>


<?php
echo '<center><H3>Welcome '.$data['name'].'</h3></center><hr>';
?>


<h3>
<?php
$mess=@$_GET['a'];
echo $mess;
?>
</h3>

<center><button name="Create New Post" onclick="showDiv()" class="button" >Ask a question</button>

<a href="edit_profile.php"><button class="button">Edit Profile</button></a>
<a href="logout.php"><button class="button">Logout</button></a>

<br>
<h3>
<?php echo @$_GET['c'];?>
<?php echo @$_GET['info'];?>
</h3>
</center> <br>

<div id="welcomeDiv"  style="display:none;" class="answer_list" > 

<h3>Create New Post</h3>
<form action="new_post_submit.php" method="POST"  enctype=multipart/form-data>

Enter title:<br>
<input type="text" name="title" required="required">
<br><br>
Describe Question:<br>
<textarea rows="10" cols="100" name="content" required="required"></textarea>
<br><br>
Attachments:<br>
<input type="file" name="image" >
<br>
<br>
<button type="submit"  class="button">Submit</button>

</form>


</div>
<br>

<?php

$query=mysqli_query($conn, 'select * from all_posts where sr="'.$sr.'"');
echo '<br>';
$count=1;
while($data=mysqli_fetch_assoc($query))
{

echo '<div class="row" style="background-color:#bbb;" style="padding:1000px">
 
 
 <div class="column">
 '.$count.': '.$data['title'].'
 </div>
 <div class="column2">
 <a href="edit_post.php?p_id='.@$data['post_id'].'"><button class="button">Edit</button></a>
 </div>
 <div class="column2">
 <a href="del.php?a='.@$data['post_id'].'"><button class="button">Delete</button></a>
 </div>
</div><br>';
	
	$count++;
}


?>


<div class="footer">
  <p>DiscussAnythingHere</p>
  All Rights Reserved 2019
</div>
</body>

</html>