Steps to start the website-
1) Copy the files on the localhost or the server.
2) Open the database folder and import the database in phpmyadmin.
3) Change the conn.php file according to the configuration of your database.
4) It will work..!!

This project has been developed by-
Aman Malhotra: 17BCA1036
AND
Aman Saxena: 17BCA1283
Contact1: malhotraaman76@gmail.com
Contact2: amananupam27@gmail.com

For Admin Panel
Page: /admin.php
Username: aman
Password: adminpass
