-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 09, 2019 at 09:03 PM
-- Server version: 10.3.16-MariaDB
-- PHP Version: 7.3.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `basedata`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_login`
--

CREATE TABLE `admin_login` (
  `sr` int(11) NOT NULL,
  `username` varchar(20) NOT NULL,
  `pwd` varchar(30) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_login`
--

INSERT INTO `admin_login` (`sr`, `username`, `pwd`) VALUES
(1, 'aman', 'adminpass');

-- --------------------------------------------------------

--
-- Table structure for table `all_posts`
--

CREATE TABLE `all_posts` (
  `sr` int(11) NOT NULL,
  `title` varchar(200) NOT NULL,
  `content` varchar(5000) NOT NULL,
  `image_path` varchar(30) NOT NULL,
  `date` varchar(20) NOT NULL,
  `post_id` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `all_posts`
--

INSERT INTO `all_posts` (`sr`, `title`, `content`, `image_path`, `date`, `post_id`) VALUES
(1, 'How much can I earn if I adopt singing as my career in India?', 'Please let me know', '1572872482.', '2019-11-04 13:01:21', '1572872482'),
(1, 'Is practicing 500 programming questions on LeetCode, HackerEarth, etc, enough to prepare for a Google interview?', 'Is it possible?', '1572872589.', '2019-11-04 13:03:08', '1572872589'),
(7, 'Linux Installation', 'How to Install Fedora ?', '1572968549.', '2019-11-05 15:42:29', '1572968549'),
(1, ' I want to self-learn computer science.', 'where can I start and what concepts should I learn?', '1572872680.', '2019-11-04 13:04:39', '1572872680'),
(4, 'How do smart people avoid negative energy?', 'How do smart people handle negative energy?', '1572872736.', '2019-11-04 13:05:36', '1572872736'),
(4, 'How much do fine artists make?', 'Give an approx idea', '1572872791.', '2019-11-04 13:06:31', '1572872791'),
(4, 'Wanna be a famous singer', 'I want to be a famous singer, I am not really good at singing but I can carry a tune and I really want to become a singer what should I do?', '1572872825.', '2019-11-04 13:07:05', '1572872825'),
(7, 'Dual Boot Windows', 'How to install Linux in Dual Boot with Windows?', '1572976644.', '2019-11-05 18:57:24', '1572976644'),
(4, 'Ethical Hacking', 'Is Hacking legal in India or if we join hands with the Indian Government to catch thieves to stop crime using our hacking skills is it legal ??', '1572980037.jpg', '2019-11-05 19:53:57', '1572980037');

-- --------------------------------------------------------

--
-- Table structure for table `contacts`
--

CREATE TABLE `contacts` (
  `sr` int(11) NOT NULL,
  `email` text NOT NULL,
  `title` text NOT NULL,
  `description` varchar(300) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contacts`
--

INSERT INTO `contacts` (`sr`, `email`, `title`, `description`) VALUES
(1, 'amananupam27@gmail.com', 'Good', 'I am impressed'),
(2, 'aman@gmail.com', 'good', 'impressive'),
(3, 'uic@gmail.com', 'good', 'very good');

-- --------------------------------------------------------

--
-- Table structure for table `login_info`
--

CREATE TABLE `login_info` (
  `sr` int(11) NOT NULL,
  `email` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `pwd` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `status` varchar(2) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `login_info`
--

INSERT INTO `login_info` (`sr`, `email`, `pwd`, `name`, `phone`, `status`) VALUES
(1, 'amananupam27@gmail.com', '8808443645', 'Aman Saxena', '8808443645', '1'),
(4, 'malhotraaman76@gmail.com', '7417566856', 'Aman Malhotra', '7417566856', '1'),
(7, 'aman@gmail.com', 'aman', 'Tester', '9876543210', '1'),
(13, 'abc@gmail.com', 'Abcd1234', 'Abc', '12345678', '1'),
(14, 'xyz@gmail.com', 'Xyz12345', 'xyz', '9876543210', '1');

-- --------------------------------------------------------

--
-- Table structure for table `post_reply`
--

CREATE TABLE `post_reply` (
  `sr` int(20) NOT NULL,
  `p_id` varchar(30) NOT NULL,
  `c_id` varchar(30) NOT NULL,
  `comment` varchar(5000) NOT NULL,
  `date` varchar(30) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `post_reply`
--

INSERT INTO `post_reply` (`sr`, `p_id`, `c_id`, `comment`, `date`) VALUES
(1, '1572842368', '1572847245', 'You need to work hard\r\n				', '2019-11-04 06:00:44'),
(4, '1572872482', '1572872951', 'No body can predict. Depends on your voice and quality of singing.People must like it. Thousands of people come to Mumbai to try their luck in Bollywood. One in lac succeeds. That may be you. First upload your song in U tyube and watch hits you get.', '2019-11-04 13:09:11'),
(4, '1572842446', '1572848754', 'chhh', '2019-11-04 06:25:53'),
(1, '1572842446', '1572857449', 'no', '2019-11-04 08:50:48'),
(4, '1572872589', '1572872997', 'Doing 500 programming questions on interview prep websites is not enough to prepare for a Google interview. Worse, itâ€™s an inadviseable waste of time to do more than a few questions on such a site.\r\n\r\nHereâ€™s other things you should be concentrating on instead.\r\n\r\nMake sure you can solve problems standing up, verbalizing what youâ€™re doing and why, and writing up code on a white board.\r\nMake sure youâ€™re comfortable being interviewed on the phone, and answering coding and technical questions over the phone or in an editor window and/or shared coding tool.\r\nReview your resume, make sure itâ€™s cogent and relevant, and make sure you can talk to the experience you list on it. Have a technical friend quiz you on it to make sure you have intelligent things to say about it.\r\nIf itâ€™s been a while since youâ€™ve brushed up on core algorithms, get an algorithms book and review heaps, binary trees, hashing, that sort of thing. Understand how they work and why.\r\nRead up a bit on Google, and make sure you understand what part youâ€™d like to work in and why, how they make their money, and their main business interests.\r\nGenerate a list of sensible questions to ask at the interview.\r\nThis will go a lot further than just solving lots of toy coding questions. Thatâ€™s a good skill to have, but far from all you need to know.\r\n\r\nAnd of course, make sure you have a way of getting a Google interview. In my experience thatâ€™s a lot more difficult than passing the interview.', '2019-11-04 13:09:56'),
(4, '1572872641', '1572873019', 'Because they are very different skill sets. Leadership is convincing people of what to do, development is solving technical problems.\r\n\r\nLeadership is setting differences within a team, development is solving technical problems.', '2019-11-04 13:10:18'),
(4, '1572872680', '1572873060', 'This is a very important and common problem faced by most Computer Science students, and infact for any student.\r\n\r\nTo self learn stuff you must have the following four qualities and resources:\r\n\r\nA laptop (if you don\'t have/can\'t afford one, use smartphone apps; a laptop is highly recommend though)\r\nAn Internet connection with at least 1 GB data per day\r\nThe ability to Google stuff fast (don\'t worry, you\'ll learn it over time)\r\nA burning desire to succeed. Unless you have this, you would give up. Computer Science is not easy for those who are not persistent.\r\nHere are the topics you should learn in the beginning:\r\n\r\nBasics of programming in either Java (most recommended)/C++/Python (least recommended).\r\nProblem solving using the above languages and understanding of important Data Structures and Algorithms.\r\nBasic Software Engineering (web development, android development, Python development, shell scripting, etc.)\r\nAfter that, you can go for specialized skills like Machine Learning/Artificial Intelligence, Cryptography/Network Security, Operating Systems, etc.\r\n\r\nThis is the path you should follow in order to self learn stuff. For a detailed understanding of Basics of Programming, you can see my article on AcadBoost.\r\n\r\nIf you follow this path, nothing can stop you from becoming a great Software Engineer/ Computer Scientist.', '2019-11-04 13:10:59'),
(1, '1572872482', '1572873109', 'Well. Thanks', '2019-11-04 13:11:48'),
(1, '1572872589', '1572873130', 'Thanks', '2019-11-04 13:12:09'),
(1, '1572872641', '1572873149', 'Thanks malhotra', '2019-11-04 13:12:28'),
(1, '1572872680', '1572873165', 'Okay. I see', '2019-11-04 13:12:45'),
(1, '1572872825', '1572873228', '				Originally Answered: I want to be a famous singer, I am not really good at singing but I can carry a tune and I really want to become a singer what should I do? ?\r\nYou want to work a karaoke shop where they do it every day. Go through their selection and start with an easy number. Considerate karaoke shops have listings by both title and artist. Nothing is wrong with trying some challenging material, and you probably want to do that on an off day; anything but the weekend. Then go home with your titles and look up the lyrics. Can you remember a tune and sing it a-cappella (vocals-only) from nothing but the lyrics? You don\'t have to do it out loud, and if you can be alone, then out loud will help you learn. Just as a keyboardist has finger memory, a singer has mouth memory. The most impressive karaoke singers memorize the lyrics: That\'s how you know that they\'ve either done the number thirty times or that they\'ve taken the time to rehearse: It would not really be karaoke for you at that point, because you could sing along with a band.\r\n\r\nIt\'s the same in a church or a barbershop chorus. While some people will have their eyes on the score, the experienced singers will be looking at a director. In order to do that, you can either take the program home and study, or keep it slack and do it next year.\r\n				', '2019-11-04 13:13:48'),
(1, '1572872791', '1572873264', 'How much money do artists make? Not nearly enough!\r\n\r\nI can only speak for Canadian artists, but I\'m sure things are similar for artists in the USA. The latest figures that I could find were gathered by Hill Strategies in 2011. This research firm reports that the average yearly income for an artist is significantly lower than it is for other workers in Canada.', '2019-11-04 13:14:24'),
(1, '1572872736', '1572873358', 'If weâ€™ve ever spent some time with a negative person, we know how quickly we can start to take on that negative mentality.\r\n\r\n1) Identify Whose Emotion is Present: If it is mine, then I can deal with it and work through those emotions, but if it is someone elseâ€™s, I need to recognize that itâ€™s not my burden to carry and let it go.\r\n\r\n2) Put Some Distance Between Me and the Negativity: Sometimes, all I need is a few minutes to regroup my thoughts and remind myself that their negativity is not my negativity.\r\n\r\n3) Know My Limits: If that negativity associated with a person, I can see it coming from a mile away and start walking in the other direction.\r\n\r\n4) Just Breathe: Take a few minutes to regulate my breathing and reset my thoughts.\r\n\r\n5) Meditate: Take a few minutes to sit quietly in my own head and meditate.\r\n\r\n6) Get Clear with People: If someone is trying to steal my sunshine, setting limits and boundaries with that person can go a long way to changing the tune of their song when they are around me. I am allowed to tell them to stop.', '2019-11-04 13:15:58'),
(4, '1572872825', '1572873426', 'Thanks bro', '2019-11-04 13:17:06'),
(4, '1572872791', '1572873438', 'Ok. I see', '2019-11-04 13:17:17'),
(4, '1572872736', '1572873458', 'Ok. I\'ll follow this. \r\nThanks', '2019-11-04 13:17:37'),
(4, '1572976644', '1572978023', 'You can use Virtual Machine like VMware Workstation for Installing Windows and Linux in virtual environment in same PC without disturbing your actual operating system.', '2019-11-05 19:20:22'),
(4, '1572968549', '1572978166', 'You can simply download and install Fedora by following the On-Screen instructions.\r\nJust make a bootable Disk of Fedora Installation Setup Files and boot your PC from the Disk and follow the on-screen instructions.', '2019-11-05 19:22:45'),
(1, '1572980037', '1572983413', 'White Hat Hacking is legal if you don\'t do any illegal activity and perform operations for the betterment of the society.', '2019-11-05 20:50:13'),
(14, '1572980037', '1573109186', 'I think if you do crime activities then only it is illegal.', '2019-11-07 07:46:26');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_login`
--
ALTER TABLE `admin_login`
  ADD PRIMARY KEY (`sr`);

--
-- Indexes for table `contacts`
--
ALTER TABLE `contacts`
  ADD PRIMARY KEY (`sr`);

--
-- Indexes for table `login_info`
--
ALTER TABLE `login_info`
  ADD PRIMARY KEY (`sr`);

--
-- Indexes for table `post_reply`
--
ALTER TABLE `post_reply`
  ADD KEY `sr` (`sr`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_login`
--
ALTER TABLE `admin_login`
  MODIFY `sr` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `contacts`
--
ALTER TABLE `contacts`
  MODIFY `sr` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `login_info`
--
ALTER TABLE `login_info`
  MODIFY `sr` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
